import logo from './logo.svg';
import './App.css';
import DataEntry from './components/DataEntry';
import Login from './components/Login';

function App() {
  return (
    <div className="App">
      <DataEntry/>
      {/* <Login/> */}
    </div>
  );
}

export default App;
